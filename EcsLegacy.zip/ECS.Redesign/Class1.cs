﻿using System;

namespace ECS.Redesign
{
    public class Class1
    {
    }
}
